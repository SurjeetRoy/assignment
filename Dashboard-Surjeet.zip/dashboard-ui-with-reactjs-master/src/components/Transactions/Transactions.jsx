import "./Transactions.css";
import { transactions } from "../../data/data";
import { iconsImgs } from "../../utils/images";

const Transactions = () => {
  const imageUrl = "https://tse4.mm.bing.net/th?id=OIP.GBqZjSRa8TVccdBXrfzOKgHaHa&pid=Api&P=0&h=180";

  return (
    <div className="grid-c1-content">
            <div className="iconStyle">
                <img src={imageUrl}
                    alt="Icon" style={{ height: '100px', width: '100px' }} />
            </div>
            <div>
                <h6 className="smtext">Orders</h6>
                <h4>$2.4K</h4>
                <div className="div">
                    <h6 className="greeText"> 7.8% </h6>
                    <h6 className="greyText">this month</h6>
                </div>
            </div>
        </div>
  )
}

export default Transactions
