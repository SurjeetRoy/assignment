import "./ContentMain.css";
import Cards from "../Cards/Cards";
import Transactions from "../Transactions/Transactions";
import Report from "../Report/Report";
import Loans from "../Loans/Loans";
import Financial from "../Financial/Financial";

const ContentMain = () => {
  return (
    <div className="main-content-holder">
      <div className="content-grid-one">
        <Cards />
        <Transactions />
        <Financial />

      </div>
      <div className="content-grid-two">
        <Report />

        <div className="grid-two-item">

          <div className="subgrid-two">
            <Loans />
          </div>
        </div>
      </div>
    </div>
  )
}

export default ContentMain
