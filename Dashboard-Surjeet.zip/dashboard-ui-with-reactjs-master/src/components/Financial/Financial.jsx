import { iconsImgs } from "../../utils/images";
import "./Financial.css";

const Financial = () => {
    const imageUrl = "https://tse3.mm.bing.net/th?id=OIP.kRh2Wo9mTv5pMPqNqct4QwHaHa&pid=Api&P=0&h=180";

    return (
        <div className="grid-c1-content">
            <div className="iconStyle">
                <img src={imageUrl}
                    alt="Icon" style={{ height: '100px', width: '100px' }} />
            </div>
            <div>
                <h6 className="smtext">Total Sales</h6>
                <h4>$89K</h4>
                <div className="div">
                    <h6 className="greeText"> 11% </h6>
                    <h6 className="greyText">this month</h6>

                </div>
            </div>
        </div>
    )
}
export default Financial
