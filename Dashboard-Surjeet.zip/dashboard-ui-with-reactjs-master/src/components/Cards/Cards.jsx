import { iconsImgs } from "../../utils/images";
import "./Cards.css";

const Cards = () => {
    const imageUrl = "https://tse4.mm.bing.net/th?id=OIP.PdgPtHNB6T5ECACljw9tvgHaHa&pid=Api&P=0&h=180";

    return (
        <div className="grid-c1-content">
            <div className="iconStyle">
                <img src={imageUrl}
                    alt="Icon" style={{ height: '100px', width: '100px' }} />
            </div>
            <div>
                <h6 className="smtext">Earning</h6>
                <h4>$198K</h4>
                <div className="div">
                    <h6 className="greeText"> 37.8% </h6>
                    <h6 className="greyText">this month</h6>

                </div>
            </div>
        </div>
    )
}
export default Cards
